import pygame
import random
import time

# wanneer de bedrieger verdacht is

pygame.init()

def Move():
    Car1.x -= snelheid1
    pygame.draw.rect(screen, (color), Car1)
    Car2.x += snelheid
    pygame.draw.rect(screen, (color), Car2)
    Car3.y -= snelheid3
    pygame.draw.rect(screen, (color), Car3)
    Car4.y += snelheid2
    pygame.draw.rect(screen, (color), Car4)

def DrawText(text, Textcolor, Rectcolor, x, y, fsize):
    font = pygame.font.Font('freesansbold.ttf', fsize)
    text = font.render(text, True, Textcolor, Rectcolor)
    textRect = text.get_rect()
    textRect.center = (x, y)
    gameDisplay.blit(text, textRect)


black = (0,0,0)
white = (255, 255, 255)
red = (255, 0, 0)
green = (0, 255, 0)
green1 = (0, 255, 0)
green2 = (0, 255, 0)
green3 = (0, 255, 0)
blue = (0,0,255)
color = white
size  = (1275, 650)
screen = pygame.display.set_mode(size)
gameDisplay = pygame.display.set_mode(size)
pygame.display.set_caption("The game")

difficulty = input("Choose difficulty (easy, normal, hard): ")

if difficulty == "easy":
  difficulty = 8
elif difficulty == "hard":
  difficulty = 16
else:
 difficulty = 12

auto1 = pygame.image.load('auto1.png').convert_alpha()
auto2 = pygame.image.load('auto2.png').convert_alpha()
auto3 = pygame.image.load('auto3.png').convert_alpha()
auto4 = pygame.image.load('auto4.png').convert_alpha()
a = pygame.image.load('achtergrond.png').convert_alpha()
achtergrond = pygame.transform.scale(a,(1275,650))

pos_x = 1275
pos_x1 = -50
pos_y2 = 650
pos_y3 = -50

snelheid = random.randint(1, difficulty)
snelheid1 = random.randint(1, difficulty)
snelheid2 = random.randint(1, difficulty)
snelheid3 = random.randint(1, difficulty)

game = True

Car1 = pygame.Rect(1290,325,40,17)
Car2 = pygame.Rect(-40,366,40,17)
Car3 = pygame.Rect(676,665,17,40)
Car4 = pygame.Rect(550,-40,17,40)

punt = 0

clock = pygame.time.Clock()
counter, text = 60, '60'.rjust(3)
pygame.time.set_timer(pygame.USEREVENT, 1000)
font = pygame.font.Font('freesansbold.ttf', 40)
Run = True
while Run:
    clock.tick(60)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Run = False
        if event.type == pygame.USEREVENT:
            counter -= 1
            text = str(counter).rjust(3) if counter > 0 else 'Finished!'
            if counter == 0:
                Run = False
    
    pos_x = pos_x - snelheid1
    pos_x1 = pos_x1 + snelheid
    pos_y2 = pos_y2 - snelheid3
    pos_y3 = pos_y3 + snelheid2

    if Car1.colliderect(Car3):
        punt -= 4
        Car1.x = Car1.x + 600
        pos_x = pos_x + 600
        Car3.y = Car3.y + 340
        pos_y2 = pos_y2 + 340
    if Car1.colliderect(Car4):
        punt -= 4
        Car1.x = Car1.x + 725
        pos_x = pos_x + 725
        Car4.y = Car4.y - 365
        pos_y3 = pos_y3 - 365
    if Car2.colliderect(Car3):
        punt -= 4
        Car2.x = Car2.x - 716
        pos_x1 = pos_x1 - 716
        Car3.y = Car3.y + 329
        pos_y2 = pos_y2 + 329
    if Car2.colliderect(Car4):
        punt -= 4
        Car2.x = Car2.x - 590
        pos_x1 = pos_x1 - 590
        Car4.y = Car4.y - 406
        pos_y3 = pos_y3 - 406

    if Car1.left <= 0:
        Car1.x = Car1.x +1275
        snelheid1 = random.randint(1, difficulty)
    if pos_x <= 0:
        pos_x = pos_x + 1275
        snelheid1 = random.randint(1, difficulty)
        punt +=1
    if Car2.left >= 1275:
        Car2.x = Car2.x - 1275
        snelheid = random.randint(1, difficulty)
    if pos_x1 >= 1275:
        pos_x1 = pos_x1 - 1275
        snelheid = random.randint(1, difficulty)
        punt +=1
    if Car3.top <= -50:
        Car3.y = Car3.y + 700
        snelheid3 = random.randint(1, difficulty)
    if pos_y2 <= -50:
        pos_y2 = pos_y2 + 700
        snelheid3 = random.randint(1, difficulty)
        punt +=1
    if Car4.bottom >= 650:
        Car4.y = Car4.y - 700
        snelheid2 = random.randint(1, difficulty)
    if pos_y3 >= 650:
        pos_y3 = pos_y3 - 700
        snelheid2 = random.randint(1, difficulty)
        punt +=1
    
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_LEFT:
            if pos_x1 <= 498:
                snelheid = 0
            green2 = (255,0,0)
        if event.key == pygame.K_RIGHT:
            if pos_x >= 718:
                snelheid1 = 0
            green = (255,0,0)
        if event.key == pygame.K_UP:
            if pos_y3 <= 305:
                snelheid2 = 0
            green1 = (255,0,0)
        if event.key == pygame.K_DOWN:
            if pos_y2 >= 387:
                snelheid3 = 0
            green3 = (255,0,0)

    if event.type == pygame.KEYUP:
        if event.key == pygame.K_LEFT:
            if pos_x1 <= 498:
                snelheid = random.randint(1, difficulty)
            green2 = (0,255,0)
        if event.key == pygame.K_RIGHT:
            if pos_x >= 718:
                snelheid1 = random.randint(1, difficulty)
            green = (0,255,0)
        if event.key == pygame.K_UP:
            if pos_y3 <= 305:
                snelheid2 = random.randint(1, difficulty)
            green1 = (0,255,0)
        if event.key == pygame.K_DOWN:
            if pos_y2 >= 387:
                snelheid3 = random.randint(1, difficulty)
            green3 = (0,255,0)

    screen.fill(white)
    Move()
    screen.blit(achtergrond, (0,0))
    screen.blit(auto1, (pos_x,305))
    screen.blit(auto2, (pos_x1,340))
    screen.blit(auto4, (650,pos_y2))
    screen.blit(auto3, (530,pos_y3))

    pygame.draw.ellipse(screen, green, [718,305,20,20])
    pygame.draw.ellipse(screen, green1, [498,305,20,20])
    pygame.draw.ellipse(screen, green2, [498,387,20,20])
    pygame.draw.ellipse(screen, green3, [718,387,20,20])

    DrawText("you have " + str(punt) + " points", black, blue, 100, 50, 20)
    screen.blit(font.render(text, True, white), (1100, 40))

    pygame.display.flip()